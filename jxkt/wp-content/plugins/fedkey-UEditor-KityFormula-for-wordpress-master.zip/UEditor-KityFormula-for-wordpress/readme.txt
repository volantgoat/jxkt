
基本信息

UEditor-KityFormula for wordpress基于Ueditor,UEditor 是由百度「FEX前端研发团队」开发的所见即所得富文本web编辑器，轻量，可定制，用户体验好。本插件将wordpress与ueditor编辑器尝试整合,并集成了KityFormula数学公式插件,无论是专心于写博客的普通人还是精于数学研究的各类人才，使用该插件都将获得很好的体验。

    分类：后台编辑器
    开发语言： php
    开放协议：GPLv2 or later
    使用场景： wordpress3.7及更高版本

功能

    文字编辑功能
    添加百度地图
    集成KityFormula,可轻松添加各式数学公式

详情见：README.md