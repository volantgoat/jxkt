=== UEditor-KityFormula-for-wordpress  === 
UEditor-KityFormula for WordPress is based on Ueditor. UEditor is the WYSIWYG rich text web editor developed by Baidu FEX front-end R & D team. It is lightweight, customizable, and user experience is good. This plug-in will try to integrate WordPress and ueditor editor, and integrate KityFormula mathematical formula plug-in. No matter what ordinary people who are interested in blogging or all kinds of talents who are good at mathematics research, using this plug-in will get a good experience.

    category：Web site editor
    development language： php
    License：GPLv2 or later
    tag:editor,web,writer
    Use the scene： wordpress3.7 or later

=== software function === 

1. Text editing function

2. Add Baidu map、google map

3. Integrating KityFormula, it is easy to add various mathematical formulas

more: see README.md